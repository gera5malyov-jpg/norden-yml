#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import sys
import time
import unicodedata
import xml.etree.ElementTree as ET
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from difflib import SequenceMatcher
from pathlib import Path

import gspread
from google.oauth2.service_account import Credentials

ROOT = Path(__file__).resolve().parents[1]
CATALOG_DIR = ROOT / "catalog"
NORDEN_DIR = ROOT / "norden-kit"
WEBASYST_DIR = ROOT / "webasyst"
sys.path.insert(0, str(WEBASYST_DIR))

from client import WebasystClient

SPREADSHEET_ID = os.environ["CATALOG_SPREADSHEET_ID"].strip()
SHEET_NAME = os.environ.get("CATALOG_SHEET", "Норден").strip()
SA_JSON = os.environ["GOOGLE_SERVICE_ACCOUNT_JSON"]
TYPE_NAME = "NORDEN-100"
WA_STOCK_NAME = "Основной склад"
KIT_MSK = "МСК"
KIT_SPB = "СПБ привозной"
BRAND = "Norden"

REPORT_PATH = CATALOG_DIR / "norden_chairs_pipeline_report.json"
STATE_PATH = CATALOG_DIR / "norden_chairs_pipeline_state.json"
CATEGORY_REVIEW_PATH = CATALOG_DIR / "norden_chairs_category_review.json"
IDENTITY_REVIEW_PATH = CATALOG_DIR / "norden_chairs_identity_review.json"

MIN_FULL_SOURCE = 5000
MIN_TARGET = 250
MIN_PRICE_ROWS = 1000

MONEY = Decimal("0.01")
WA_SALE_MULT = Decimal("1.23")
KIT_SALE_MULT = Decimal("1.26")
OLD_MULT = Decimal("1.65")

SUPPLIER_COLUMNS = ("Закупка", "РРЦ поставщика", "Остаток")
ACCESSORY_WORDS = (
    "чехол", "подголовник", "подлокотник", "газлифт", "крестовин",
    "ролик", "колесо", "колеса", "механизм", "комплектующие",
    "запчаст", "накладка", "основание для кресла",
)
PRIVATE_FEATURES = {
    "поставщик", "остаток", "остатки", "наличие", "склад",
    "ндс", "ставка ндс",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def s(v) -> str:
    return str(v or "").strip()


def nt(v) -> str:
    return re.sub(r"[^0-9a-zа-яё]+", "", unicodedata.normalize("NFKC", s(v)).casefold())


def money(v):
    if v in (None, ""):
        return None
    try:
        d = Decimal(str(v).replace(" ", "").replace(",", "."))
    except (InvalidOperation, ValueError, TypeError):
        return None
    if d < 0:
        return None
    return d.quantize(MONEY, rounding=ROUND_HALF_UP)


def money_str(v):
    d = money(v)
    return None if d is None else f"{d:.2f}"


def price(v, multiplier):
    d = money(v)
    if d is None or d <= 0:
        return None
    return (d * multiplier).quantize(MONEY, rounding=ROUND_HALF_UP)


def as_qty(v):
    if v in (None, ""):
        return 0
    try:
        return max(0, int(Decimal(str(v).replace(" ", "").replace(",", "."))))
    except Exception:
        return 0


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


norden = load_module("norden_sync_for_chairs_pipeline", NORDEN_DIR / "sync_norden_kit.py")
kit_bridge = load_module("norden_kit_bridge_for_pipeline", NORDEN_DIR / "webasyst_n100_to_kit_once.py")


def supplier_key(v):
    return norden.norm_code(v)


def category_is_chair_stool(item):
    parts = [s(x).casefold().replace("ё", "е") for x in (item.get("category_path") or [])]
    if not any(("кресл" in p) or ("стул" in p) for p in parts):
        return False
    name = s(item.get("name")).casefold().replace("ё", "е")
    if any(word in name for word in ACCESSORY_WORDS):
        return False
    return bool(re.search(r"(^|[\s/(\-])(кресло|кресла|стул|стулья)([\s/),\-]|$)", name))


def row_looks_chair_stool(name):
    x = s(name).casefold().replace("ё", "е")
    if any(word in x for word in ACCESSORY_WORDS):
        return False
    return bool(re.search(r"(^|[\s/(\-])(кресло|кресла|стул|стулья)([\s/),\-]|$)", x))


def load_price_detail():
    raw = norden.download_bytes(norden.PRICE_XML_URL)
    root = ET.fromstring(raw)
    out = {}
    duplicates = []
    for node in root.iter("Номенклатура"):
        article = s(node.findtext("Артикул"))
        if not article:
            continue
        prices = {}
        for p in node.findall("Цена"):
            kind = s(p.attrib.get("ВидЦен")).casefold()
            if kind:
                prices[kind] = money(p.text)
        stocks = {}
        for st in node.findall("СвободныйОстаток"):
            wh = s(st.attrib.get("Склад"))
            if wh:
                stocks[wh] = as_qty(st.text)
        row = {
            "article": article,
            "purchase": prices.get("опт"),
            "rrp": prices.get("ррц"),
            "msk": as_qty(stocks.get("Основной склад")),
            "spb": as_qty(stocks.get("Питер Основной склад")),
        }
        row["total"] = row["msk"] + row["spb"]
        key = supplier_key(article)
        if key in out:
            duplicates.append(article)
        out[key] = row
    return out, duplicates


def load_supplier():
    secret = os.environ.get("NORDEN_SECRET", "").strip()
    full, duplicates, source_kind, api_error = norden.load_source(secret, short=False)
    price_index, price_dups = load_price_detail()
    if len(full) < MIN_FULL_SOURCE:
        raise RuntimeError(f"Safety stop: Norden full catalog too small: {len(full)}")
    target = {}
    target_key_owner = {}
    target_conflicts = []
    for article, raw in full.items():
        if not category_is_chair_stool(raw):
            continue
        item = dict(raw)
        key = supplier_key(article)
        p = price_index.get(key)
        if p:
            item["purchase"] = p["purchase"]
            item["rrp"] = p["rrp"]
            item["stock_msk"] = p["msk"]
            item["stock_spb"] = p["spb"]
            item["stock_total"] = p["total"]
        else:
            item["purchase"] = None
            item["rrp"] = None
            item["stock_msk"] = 0
            item["stock_spb"] = 0
            item["stock_total"] = 0
        item["article"] = article
        if key in target_key_owner and target_key_owner[key] != article:
            target_conflicts.append([target_key_owner[key], article])
            continue
        target_key_owner[key] = article
        target[key] = item
    if len(price_index) < MIN_PRICE_ROWS:
        raise RuntimeError(f"Safety stop: Norden price feed too small: {len(price_index)}")
    if len(target) < MIN_TARGET:
        raise RuntimeError(f"Safety stop: Norden chair/stool scope too small: {len(target)}")
    return target, {
        "full_count": len(full),
        "target_count": len(target),
        "price_count": len(price_index),
        "full_duplicates": len(duplicates),
        "price_duplicates": len(price_dups),
        "target_key_conflicts": target_conflicts,
        "source_kind": source_kind,
        "api_error": api_error,
    }


def load_state():
    if not STATE_PATH.exists():
        return {"version": 1, "managed_yml_ids": []}
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise ValueError
        return data
    except Exception:
        return {"version": 1, "managed_yml_ids": []}


def google_sheet():
    creds = json.loads(SA_JSON)
    gc = gspread.authorize(Credentials.from_service_account_info(
        creds,
        scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive",
        ],
    ))
    sh = gc.open_by_key(SPREADSHEET_ID)
    return sh, sh.worksheet(SHEET_NAME)


def ensure_headers(ws, values):
    if not values:
        raise RuntimeError("Норден sheet is empty")
    headers = list(values[0])
    for h in SUPPLIER_COLUMNS:
        if h not in headers:
            headers.append(h)
    required = [
        "Артикул", "Название", "YML ID", "Бренд", "Источник", "Тип Webasyst при загрузке",
        "Webasyst product_id", "Webasyst sku_id", "Цена Webasyst",
        "Старая цена Webasyst", "Закупочная цена Webasyst",
    ]
    missing = [h for h in required if h not in headers]
    if missing:
        raise RuntimeError(f"Missing required sheet columns: {missing}")
    if ws.col_count < len(headers):
        ws.resize(cols=len(headers))
    ws.update(
        range_name=f"A1:{gspread.utils.rowcol_to_a1(1, len(headers))}",
        values=[headers],
        value_input_option="RAW",
    )
    return headers


def cell(row, idx, name):
    pos = idx.get(name)
    return s(row[pos] if pos is not None and pos < len(row) else "")


def set_row_value(row, idx, name, value):
    if name not in idx:
        return
    while len(row) < len(idx):
        row.append("")
    row[idx[name]] = "" if value is None else value



def potential_table_matches(item, rows, idx):
    """Conservative duplicate gate. It never merges; it only blocks auto-create for review."""
    skey = supplier_key(item.get("article"))
    sname = nt(item.get("name"))
    candidates = []
    for rec in rows:
        row = rec["row"]
        if s(cell(row, idx, "Бренд")).casefold() != BRAND.casefold():
            continue
        if not row_looks_chair_stool(cell(row, idx, "Название")):
            continue
        yml = cell(row, idx, "YML ID")
        tkey = supplier_key(yml)
        name = cell(row, idx, "Название")
        nname = nt(name)
        reasons = []
        score = 0.0
        if skey and tkey:
            short, long = (skey, tkey) if len(skey) <= len(tkey) else (tkey, skey)
            ratio = len(short) / max(1, len(long))
            if len(short) >= 5 and short in long and ratio >= 0.68:
                reasons.append(f"ID containment {ratio:.2f}")
                score = max(score, 0.92)
            cp = 0
            for a, b in zip(skey, tkey):
                if a != b:
                    break
                cp += 1
            cs = 0
            for a, b in zip(reversed(skey), reversed(tkey)):
                if a != b:
                    break
                cs += 1
            common_ratio = max(cp, cs) / max(1, min(len(skey), len(tkey)))
            if min(len(skey), len(tkey)) >= 6 and common_ratio >= 0.82:
                reasons.append(f"ID common edge {common_ratio:.2f}")
                score = max(score, 0.88)
        if sname and nname:
            ns = SequenceMatcher(None, sname, nname).ratio()
            if ns >= 0.90:
                reasons.append(f"name {ns:.2f}")
                score = max(score, ns)
        if reasons:
            candidates.append({
                "row": rec["rowno"],
                "table_article": cell(row, idx, "Артикул"),
                "table_yml_id": yml,
                "table_name": name,
                "score": round(score, 4),
                "reason": "; ".join(reasons),
            })
    candidates.sort(key=lambda x: (-x["score"], x["row"]))
    return candidates[:5]


def extimg_summary(urls):
    urls = list(dict.fromkeys(s(x) for x in urls if s(x)))
    return "\n".join(f"[extimg]\n{u}\n[/extimg]" for u in urls)


def listify(payload, keys=()):
    if isinstance(payload, list):
        return [x for x in payload if isinstance(x, dict)]
    if not isinstance(payload, dict):
        return []
    for key in keys:
        v = payload.get(key)
        if isinstance(v, list):
            return [x for x in v if isinstance(x, dict)]
        if isinstance(v, dict):
            return [x for x in v.values() if isinstance(x, dict)]
    if payload and all(isinstance(v, dict) for v in payload.values()):
        return list(payload.values())
    return []


def product_skus(product):
    v = product.get("skus")
    if isinstance(v, dict):
        return [x for x in v.values() if isinstance(x, dict)]
    if isinstance(v, list):
        return [x for x in v if isinstance(x, dict)]
    return []


def extract_product_id(payload):
    if isinstance(payload, dict):
        for key in ("id", "product_id"):
            if payload.get(key) not in (None, ""):
                return s(payload.get(key))
        p = payload.get("product")
        if isinstance(p, dict):
            return s(p.get("id"))
    return ""


def wa_stock_qty(sku, stock_id):
    raw = sku.get("stock")
    if isinstance(raw, dict):
        for key in (stock_id, str(stock_id)):
            if key in raw:
                return as_qty(raw[key])
    counts = sku.get("stock_counts")
    if isinstance(counts, dict):
        for key in (stock_id, str(stock_id)):
            if key in counts:
                v = counts[key]
                if isinstance(v, dict):
                    v = v.get("count") or v.get("quantity") or v.get("stock")
                return as_qty(v)
    return None


def load_wa_products(wa, type_id):
    out = []
    offset = 0
    while True:
        payload = wa.call(
            "shop.product.search",
            params={
                "hash": f"type/{type_id}",
                "offset": offset,
                "limit": 1000,
                "fields": "*,skus,stock_counts",
            },
        )
        batch = listify(payload, ("products", "items"))
        out.extend(batch)
        total = (payload.get("count") or payload.get("total_count")) if isinstance(payload, dict) else None
        if not batch or len(batch) < 1000:
            break
        if total not in (None, "") and len(out) >= int(total):
            break
        offset += len(batch)
    return out


def resolve_wa(wa):
    types = listify(wa.call("shop.type.getList"))
    matches = [x for x in types if nt(x.get("name") or x.get("title")) == nt(TYPE_NAME)]
    if len(matches) != 1:
        raise RuntimeError(f"Expected exactly one Webasyst type {TYPE_NAME!r}, found {len(matches)}")
    type_id = s(matches[0].get("id"))
    stocks = listify(wa.call("shop.stock.getList"))
    sm = [x for x in stocks if nt(x.get("name") or x.get("title")) == nt(WA_STOCK_NAME)]
    if len(sm) != 1:
        raise RuntimeError(f"Expected exactly one Webasyst stock {WA_STOCK_NAME!r}, found {len(sm)}")
    return type_id, s(sm[0].get("id"))


def create_wa_product(wa, type_id, stock_id, item, desired_article=""):
    purchase = money(item.get("purchase"))
    if purchase is None or purchase <= 0:
        raise RuntimeError("Нет положительной закупочной цены Norden")
    sale = price(purchase, WA_SALE_MULT)
    compare = price(purchase, OLD_MULT)
    sku_payload = {
        "price": money_str(sale),
        "compare_price": money_str(compare),
        "purchase_price": money_str(purchase),
        "stock": {stock_id: str(as_qty(item.get("stock_total")))},
        "available": 1,
        "status": 1,
    }
    if desired_article:
        sku_payload["sku"] = desired_article
    created = wa.call(
        "shop.product.add",
        http_method="POST",
        data={
            "name": s(item.get("name")) or s(item.get("article")),
            "type_id": type_id,
            "currency": "RUB",
            "summary": extimg_summary(item.get("images") or []),
            "description": s(item.get("description")),
            "status": 1,
            "skus": [sku_payload],
        },
    )
    pid = extract_product_id(created)
    if not pid:
        raise RuntimeError(f"shop.product.add did not return product id: {str(created)[:500]}")
    skus = listify(wa.call("shop.product.skus.getList", params={"product_id": pid}), ("skus", "items"))
    if len(skus) != 1:
        raise RuntimeError(f"New Webasyst product {pid} has {len(skus)} SKUs")
    sku = skus[0]
    sid = s(sku.get("id"))
    generated = s(sku.get("sku"))
    if desired_article and generated != desired_article:
        wa.call(
            "shop.product.skus.update",
            http_method="POST",
            params={"id": sid},
            data={"sku": desired_article},
        )
        generated = desired_article
    if not generated:
        raise RuntimeError("Webasyst did not generate an article/SKU")
    return pid, sid, generated


def sync_webasyst(rows, idx, target, managed_keys, ws, report):
    wa = WebasystClient(min_request_interval=0.50)
    type_id, stock_id = resolve_wa(wa)
    products = load_wa_products(wa, type_id)
    wa_by_sku = defaultdict(list)
    for p in products:
        for sku in product_skus(p):
            key = nt(sku.get("sku"))
            if key:
                wa_by_sku[key].append((p, sku))
    duplicate_wa = {k: v for k, v in wa_by_sku.items() if len(v) > 1}
    report["webasyst"]["duplicate_articles"] = len(duplicate_wa)

    sheet_updates = []
    for rec in rows:
        key = rec["key"]
        if key not in managed_keys:
            continue
        row = rec["row"]
        rowno = rec["rowno"]
        item = target.get(key)
        article = cell(row, idx, "Артикул")
        stock = as_qty(item.get("stock_total")) if item else 0

        if not article:
            if not item:
                report["webasyst"]["skipped_no_article"] += 1
                continue
            try:
                pid, sid, generated = create_wa_product(wa, type_id, stock_id, item, "")
                article = generated
                set_row_value(row, idx, "Артикул", generated)
                set_row_value(row, idx, "Webasyst product_id", pid)
                set_row_value(row, idx, "Webasyst sku_id", sid)
                set_row_value(row, idx, "Тип Webasyst при загрузке", TYPE_NAME)
                set_row_value(row, idx, "Цена Webasyst", money_str(price(item["purchase"], WA_SALE_MULT)))
                set_row_value(row, idx, "Старая цена Webasyst", money_str(price(item["purchase"], OLD_MULT)))
                set_row_value(row, idx, "Закупочная цена Webasyst", money_str(item["purchase"]))
                report["webasyst"]["created"] += 1
                wa_by_sku[nt(article)].append(({"id": pid, "name": item.get("name")}, {"id": sid, "sku": article}))
                for h in ("Артикул", "Webasyst product_id", "Webasyst sku_id", "Тип Webasyst при загрузке",
                          "Цена Webasyst", "Старая цена Webasyst", "Закупочная цена Webasyst"):
                    sheet_updates.append({
                        "range": gspread.utils.rowcol_to_a1(rowno, idx[h] + 1),
                        "values": [[row[idx[h]]]],
                    })
            except Exception as exc:
                report["errors"].append({"stage": "webasyst_create", "row": rowno, "yml_id": cell(row, idx, "YML ID"), "message": str(exc)[:1000]})
                continue

        candidates = wa_by_sku.get(nt(article), [])
        if len(candidates) > 1:
            report["webasyst"]["skipped_duplicate_article"] += 1
            continue
        if not candidates:
            if not item:
                report["webasyst"]["missing_existing"] += 1
                continue
            try:
                pid, sid, generated = create_wa_product(wa, type_id, stock_id, item, article)
                candidates = [({"id": pid, "name": item.get("name")}, {"id": sid, "sku": generated})]
                wa_by_sku[nt(article)] = candidates
                report["webasyst"]["created"] += 1
            except Exception as exc:
                report["errors"].append({"stage": "webasyst_create_existing_article", "row": rowno, "article": article, "message": str(exc)[:1000]})
                continue

        product, sku = candidates[0]
        sid = s(sku.get("id"))
        if not sid:
            report["errors"].append({"stage": "webasyst_update", "row": rowno, "article": article, "message": "SKU id is empty"})
            continue
        changes = {}
        if wa_stock_qty(sku, stock_id) != stock:
            changes["stock"] = {stock_id: str(stock)}
        if item and money(item.get("purchase")) and money(item.get("purchase")) > 0:
            purchase = money(item["purchase"])
            sale = price(purchase, WA_SALE_MULT)
            compare = price(purchase, OLD_MULT)
            if money(sku.get("purchase_price")) != purchase:
                changes["purchase_price"] = money_str(purchase)
            if money(sku.get("price")) != sale:
                changes["price"] = money_str(sale)
            if money(sku.get("compare_price")) != compare:
                changes["compare_price"] = money_str(compare)
        if changes:
            try:
                wa.call("shop.product.skus.update", http_method="POST", params={"id": sid}, data=changes)
                report["webasyst"]["updated"] += 1
            except Exception as exc:
                report["errors"].append({"stage": "webasyst_update", "row": rowno, "article": article, "message": str(exc)[:1000]})
        else:
            report["webasyst"]["unchanged"] += 1

    if sheet_updates:
        for i in range(0, len(sheet_updates), 250):
            ws.batch_update(sheet_updates[i:i+250], value_input_option="RAW")


def kit_char_value(row, cid):
    for c in row.get("characteristics") or []:
        if s(c.get("characteristic_id")) == s(cid):
            vals = c.get("values") or []
            return s(c.get("value")) or (s(vals[0]) if vals else "")
    return ""


def public_item(item):
    x = dict(item)
    filtered = []
    for title, value in item.get("characteristics") or []:
        if nt(title) in {nt(z) for z in PRIVATE_FEATURES}:
            continue
        filtered.append((title, value))
    x["characteristics"] = filtered
    return x


def resolve_kit_warehouses(kit):
    rows = kit.warehouses()
    out = {}
    for title in (KIT_MSK, KIT_SPB):
        matches = [s(x.get("id")) for x in rows if s(x.get("title") or x.get("name")) == title and s(x.get("id"))]
        if len(matches) != 1:
            raise RuntimeError(f"Expected exactly one KIT warehouse {title!r}, found {len(matches)}")
        out[title] = matches[0]
    return out


def bulk_post(kit, path, items, batch_size=2000):
    for i in range(0, len(items), batch_size):
        kit.request("POST", path, body={"items": items[i:i+batch_size]})


def sync_kit(rows, idx, target, managed_keys, report):
    kit = kit_bridge.KitClient()
    wh = resolve_kit_warehouses(kit)
    all_chars, chars_by_title, code_site_id, article_id = norden.resolve_special_characteristics(kit)

    index = defaultdict(list)
    scanned = 0
    for v in kit.scan_all_variants_parallel(workers=8):
        scanned += 1
        if s(v.get("status")).upper() == "ARCHIVED":
            continue
        values = [s(v.get("sku")), kit_char_value(v, article_id)]
        for value in values:
            k = nt(value)
            if k:
                index[k].append(v)
    report["kit"]["variants_scanned"] = scanned
    report["kit"]["duplicate_articles"] = sum(1 for v in index.values() if len({s(x.get("id")) for x in v}) > 1)

    categories = kit.categories()
    price_rows = []
    stock_rows = []
    review = []

    for rec in rows:
        key = rec["key"]
        if key not in managed_keys:
            continue
        row = rec["row"]
        rowno = rec["rowno"]
        article = cell(row, idx, "Артикул")
        item = target.get(key)
        if not article:
            report["kit"]["skipped_no_article"] += 1
            continue

        candidates_by_id = {}
        for v in index.get(nt(article), []):
            vid = s(v.get("id"))
            if vid:
                candidates_by_id[vid] = v
        candidates = list(candidates_by_id.values())

        if len(candidates) > 1:
            report["kit"]["skipped_duplicate_article"] += 1
            continue

        if not candidates:
            if not item:
                report["kit"]["missing_existing"] += 1
                continue
            approved = norden.approved_category_path(item.get("category_path") or [])
            if not approved:
                review.append({
                    "row": rowno,
                    "article": article,
                    "yml_id": item.get("article"),
                    "name": item.get("name"),
                    "source_category": " > ".join(item.get("category_path") or []),
                    "reason": "CATEGORY_REVIEW_REQUIRED",
                })
                report["kit"]["category_review_required"] += 1
                continue
            if money(item.get("purchase")) is None or money(item.get("purchase")) <= 0:
                report["kit"]["skipped_no_purchase_price"] += 1
                continue
            try:
                category_id = norden.ensure_category_path(kit, categories, approved)
                p = kit.create_product(category_id)
                product_id = s(p.get("id"))
                if not product_id:
                    raise RuntimeError("KIT create_product returned no id")
                sale = price(item["purchase"], KIT_SALE_MULT)
                old = price(item["purchase"], OLD_MULT)
                body = {
                    "sku": article,
                    "name": s(item.get("name")) or article,
                    "status": "PUBLISHED",
                    "product_id": product_id,
                    "brand": BRAND,
                    "stocks": [
                        {"warehouse_id": wh[KIT_MSK], "quantity": as_qty(item.get("stock_msk")), "reserved": 0},
                        {"warehouse_id": wh[KIT_SPB], "quantity": as_qty(item.get("stock_spb")), "reserved": 0},
                    ],
                    "pricing": {
                        "price": money_str(old),
                        "manual_discount_price": money_str(sale),
                    },
                }
                created = kit.create_variant(body)
                vid = s(created.get("id"))
                if not vid:
                    raise RuntimeError("KIT create_variant returned no id")
                item_public = public_item(item)
                characteristics = norden.build_source_characteristics(
                    item_public, kit, all_chars, chars_by_title,
                    code_site_id, article_id=article_id, new_article=article,
                )
                patch = {"characteristics": characteristics}
                if s(item.get("description")):
                    patch["description"] = s(item.get("description"))
                media = []
                for url in (item.get("images") or [])[:20]:
                    try:
                        uploaded = kit.upload_image_url(url)
                        fid = s(uploaded.get("id"))
                        if fid:
                            media.append({"type": "IMAGE", "display_sequence": len(media), "image_id": fid})
                            report["kit"]["images_uploaded"] += 1
                    except Exception as exc:
                        report["warnings"].append(f"KIT image {article}: {str(exc)[:300]}")
                if media:
                    patch["media"] = media
                kit.patch_variant(vid, patch)
                v = kit.request("GET", f"/v1/variants/{vid}")
                index[nt(article)].append(v if isinstance(v, dict) else {"id": vid, "sku": article})
                candidates = index[nt(article)]
                report["kit"]["created"] += 1
            except Exception as exc:
                report["errors"].append({"stage": "kit_create", "row": rowno, "article": article, "message": str(exc)[:1000]})
                continue

        v = candidates[0]
        vid = s(v.get("id"))
        if not vid:
            continue
        msk = as_qty(item.get("stock_msk")) if item else 0
        spb = as_qty(item.get("stock_spb")) if item else 0
        stock_rows.extend([
            {"variant_id": vid, "warehouse_id": wh[KIT_MSK], "quantity": msk},
            {"variant_id": vid, "warehouse_id": wh[KIT_SPB], "quantity": spb},
        ])
        if item and money(item.get("purchase")) and money(item.get("purchase")) > 0:
            sale = price(item["purchase"], KIT_SALE_MULT)
            old = price(item["purchase"], OLD_MULT)
            price_rows.append({
                "variant_id": vid,
                "price": money_str(old),
                "manual_discount_price": money_str(sale),
            })

    try:
        if price_rows:
            bulk_post(kit, "/v1/variants/prices/bulk_update", price_rows)
            report["kit"]["price_updates"] = len(price_rows)
        if stock_rows:
            bulk_post(kit, "/v1/variants/stocks/bulk_update", stock_rows)
            report["kit"]["stock_updates"] = len(stock_rows)
    except Exception as exc:
        report["errors"].append({"stage": "kit_bulk_update", "message": str(exc)[:1000]})

    return review


def main():
    started = now_iso()
    report = {
        "started_at": started,
        "scope": "Norden: only actual chairs and stools; accessories excluded",
        "rules": {
            "table_match": "Norden supplier article ↔ Google Sheet YML ID, normalized",
            "table_missing": "managed chair/stool missing from complete supplier catalog => stock 0; prices unchanged",
            "webasyst": "type NORDEN-100; match by Article; stock Main; purchase=Opt; sale=purchase*1.23; compare=purchase*1.65",
            "kit": "match by Article; MСК and СПБ привозной; sale=purchase*1.26; compare=purchase*1.65; minimum price unchanged",
            "new": "table first -> Webasyst -> Webasyst-generated Article -> KIT; no KIT creation without approved category",
            "old_norden_stop": "STOP_ALL_NORDEN remains active for legacy Norden workflows",
        },
        "supplier": {},
        "table": {
            "rows_before": 0, "matched": 0, "new_rows": 0, "zeroed_missing": 0,
            "duplicate_yml_ids": 0, "price_updates": 0, "stock_updates": 0,
        },
        "webasyst": defaultdict(int),
        "kit": defaultdict(int),
        "errors": [],
        "warnings": [],
        "complete": False,
    }

    target, supplier_meta = load_supplier()
    report["supplier"] = supplier_meta

    state = load_state()
    previous_managed = {supplier_key(x) for x in state.get("managed_yml_ids") or [] if supplier_key(x)}

    sh, ws = google_sheet()
    values = ws.get_all_values()
    headers = ensure_headers(ws, values)
    idx = {h: i for i, h in enumerate(headers)}
    report["table"]["rows_before"] = len(values) - 1

    rows = []
    yml_map = defaultdict(list)
    for rowno, src in enumerate(values[1:], start=2):
        row = list(src) + [""] * max(0, len(headers) - len(src))
        yml = cell(row, idx, "YML ID")
        key = supplier_key(yml)
        rec = {"rowno": rowno, "row": row, "key": key}
        rows.append(rec)
        if key:
            yml_map[key].append(rec)

    duplicate_yml = {k: v for k, v in yml_map.items() if len(v) > 1}
    report["table"]["duplicate_yml_ids"] = len(duplicate_yml)

    heuristic_managed = set()
    for rec in rows:
        if not rec["key"]:
            continue
        row = rec["row"]
        if s(cell(row, idx, "Бренд")).casefold() == BRAND.casefold() and row_looks_chair_stool(cell(row, idx, "Название")):
            heuristic_managed.add(rec["key"])

    managed_keys = set(target) | previous_managed | heuristic_managed

    updates = []
    for rec in rows:
        key = rec["key"]
        if not key or key not in managed_keys or key in duplicate_yml:
            continue
        row = rec["row"]
        rowno = rec["rowno"]
        item = target.get(key)
        if item:
            report["table"]["matched"] += 1
            desired = {
                "Закупка": money_str(item["purchase"]) if item.get("purchase") is not None else None,
                "РРЦ поставщика": money_str(item["rrp"]) if item.get("rrp") is not None else None,
                "Остаток": as_qty(item.get("stock_total")),
            }
            for h, val in desired.items():
                if val is None and h != "Остаток":
                    continue
                old = cell(row, idx, h)
                new = str(val)
                if old != new:
                    set_row_value(row, idx, h, val)
                    updates.append({"range": gspread.utils.rowcol_to_a1(rowno, idx[h] + 1), "values": [[val]]})
                    if h == "Остаток":
                        report["table"]["stock_updates"] += 1
                    else:
                        report["table"]["price_updates"] += 1
        else:
            if cell(row, idx, "Остаток") != "0":
                set_row_value(row, idx, "Остаток", 0)
                updates.append({"range": gspread.utils.rowcol_to_a1(rowno, idx["Остаток"] + 1), "values": [[0]]})
                report["table"]["zeroed_missing"] += 1

    new_rows = []
    identity_review = []
    existing_keys = set(yml_map)
    for key, item in target.items():
        if key in existing_keys or key in duplicate_yml:
            continue
        potential = potential_table_matches(item, rows, idx)
        if potential:
            identity_review.append({
                "supplier_article": item.get("article"),
                "supplier_name": item.get("name"),
                "source_category": " > ".join(item.get("category_path") or []),
                "candidates": potential,
                "reason": "POTENTIAL_EXISTING_PRODUCT_REVIEW_REQUIRED",
            })
            continue
        row = [""] * len(headers)
        set_row_value(row, idx, "Название", item.get("name"))
        set_row_value(row, idx, "YML ID", item.get("article"))
        set_row_value(row, idx, "Бренд", BRAND)
        set_row_value(row, idx, "Источник", "Norden")
        set_row_value(row, idx, "Тип Webasyst при загрузке", TYPE_NAME)
        set_row_value(row, idx, "Закупка", money_str(item["purchase"]) if item.get("purchase") is not None else "")
        set_row_value(row, idx, "РРЦ поставщика", money_str(item["rrp"]) if item.get("rrp") is not None else "")
        set_row_value(row, idx, "Остаток", as_qty(item.get("stock_total")))
        if "Фото" in idx:
            set_row_value(row, idx, "Фото", json.dumps(item.get("images") or [], ensure_ascii=False))
        if "Основное фото" in idx and item.get("images"):
            set_row_value(row, idx, "Основное фото", f'=IMAGE("{s(item["images"][0]).replace(chr(34), chr(34)*2)}")')
        new_rows.append(row)

    if updates:
        for i in range(0, len(updates), 250):
            ws.batch_update(updates[i:i+250], value_input_option="RAW")

    if new_rows:
        start = len(values) + 1
        needed = start + len(new_rows) + 10
        if ws.row_count < needed:
            ws.resize(rows=needed)
        for i in range(0, len(new_rows), 50):
            batch = new_rows[i:i+50]
            r1 = start + i
            r2 = r1 + len(batch) - 1
            ws.update(
                range_name=f"A{r1}:{gspread.utils.rowcol_to_a1(r2, len(headers))}",
                values=batch,
                value_input_option="USER_ENTERED",
            )
        for i, row in enumerate(new_rows):
            rowno = start + i
            key = supplier_key(row[idx["YML ID"]])
            rec = {"rowno": rowno, "row": row, "key": key}
            rows.append(rec)
            yml_map[key].append(rec)
        report["table"]["new_rows"] = len(new_rows)

    IDENTITY_REVIEW_PATH.write_text(json.dumps({
        "updated_at": now_iso(),
        "count": len(identity_review),
        "items": identity_review,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    report["identity_review"] = len(identity_review)

    # Downstream systems only after Google Sheet phase has completed.
    # Items held for identity review were not added to the sheet and cannot be auto-created downstream.
    sync_webasyst(rows, idx, target, managed_keys, ws, report)
    review = sync_kit(rows, idx, target, managed_keys, report)

    # Persist scope so a future complete-feed disappearance is safely zeroed.
    exact_ids = []
    for key in sorted(managed_keys):
        if key in target:
            exact_ids.append(s(target[key].get("article")))
        elif key in yml_map and yml_map[key]:
            exact_ids.append(cell(yml_map[key][0]["row"], idx, "YML ID"))
    state_out = {
        "version": 2,
        "updated_at": now_iso(),
        "managed_yml_ids": list(dict.fromkeys(x for x in exact_ids if x)),
        "scope": "Norden actual chairs/stools only",
    }
    STATE_PATH.write_text(json.dumps(state_out, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    CATEGORY_REVIEW_PATH.write_text(json.dumps({
        "updated_at": now_iso(),
        "count": len(review),
        "items": review,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    report["webasyst"] = dict(report["webasyst"])
    report["kit"] = dict(report["kit"])
    report["category_review"] = len(review)
    report["finished_at"] = now_iso()
    report["complete"] = not report["errors"]
    REPORT_PATH.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return 0 if report["complete"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
